﻿namespace Exact
{
    static class Constants
    {
        // API key = C#  
        public const string BASE_URI = "https://start.exactonline.nl";
        public const string CLIENT_ID = "5f1e332d-db33-45bc-8a37-f9abdd8cc7a3";
        public const string CLIENT_SECRET = "OPzAVfzKhWQu";
        public const string CLIENT_STATE = "1wzxvfh2naf3vvkj2lprxyda";
        public const string CALLBACK_URL = "http://localhost:8080/map/exact/callback.php";
    }
}
